create view users_logged_today as
select `practice`.`users`.`id`         AS `id`,
       `practice`.`users`.`username`   AS `username`,
       `practice`.`users`.`password`   AS `password`,
       `practice`.`users`.`full_name`  AS `full_name`,
       `practice`.`users`.`last_login` AS `last_login`
from `practice`.`users`
where `practice`.`users`.`last_login` >= current_timestamp() - interval 1 day;

